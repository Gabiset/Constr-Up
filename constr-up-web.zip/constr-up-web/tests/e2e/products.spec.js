import { expect, test } from "@playwright/test";
import { randomUUID } from "node:crypto";

// Requer a API local e um banco de desenvolvimento. Só cria/remove o próprio produto.
test("cadastra, encontra, edita, cancela e confirma uma exclusão", async ({
  page,
  request,
}) => {
  const name = `E2E-${randomUUID().slice(0, 8)}`;
  const api = process.env.E2E_API_URL || "http://127.0.0.1:8000/api";
  let productId;
  try {
    await page.goto("/");
    await expect(
      page.getByRole("heading", { name: "Seus produtos." }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Novo produto", exact: true })
      .click();
    await page.getByLabel("Nome do produto", { exact: true }).fill(name);
    await page.getByLabel("Marca", { exact: true }).fill("Teste E2E");
    await page
      .getByLabel("Descrição", { exact: true })
      .fill("Produto temporário do teste automatizado.");
    await page.getByLabel("Preço unitário (R$)", { exact: true }).fill("32,90");
    await page.getByLabel("Estoque (unidades)", { exact: true }).fill("8");
    const created = page.waitForResponse(
      (response) =>
        response.url().endsWith("/products") &&
        response.request().method() === "POST",
    );
    await page.getByRole("button", { name: "Salvar produto" }).click();
    const response = await created;
    expect(response.status()).toBe(201);
    productId = (await response.json()).data.id;
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await page.getByRole("searchbox", { name: "Buscar produtos" }).fill(name);
    const row = page.getByRole("row").filter({ hasText: name });
    await expect(row).toHaveCount(1);
    await row
      .getByRole("button", { name: `Editar ${name}`, exact: true })
      .click();
    await expect(
      page.getByLabel("Preço unitário (R$)", { exact: true }),
    ).toHaveValue("32,90");
    await page.getByLabel("Estoque (unidades)", { exact: true }).fill("3");
    await page.getByRole("button", { name: "Salvar produto" }).click();
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(row.getByText("Estoque baixo", { exact: true })).toBeVisible();
    await row
      .getByRole("button", { name: `Excluir ${name}`, exact: true })
      .click();
    await page.getByRole("button", { name: "Cancelar", exact: true }).click();
    await expect(row).toHaveCount(1);
    await row
      .getByRole("button", { name: `Excluir ${name}`, exact: true })
      .click();
    await page
      .getByRole("button", { name: "Excluir produto", exact: true })
      .click();
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(
      page.getByRole("heading", { name: "Nenhum produto encontrado" }),
    ).toBeVisible();
    const missing = await request.get(`${api}/products/${productId}`);
    expect(missing.status()).toBe(404);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
    ).toBe(true);
  } finally {
    if (productId) await request.delete(`${api}/products/${productId}`);
  }
});
