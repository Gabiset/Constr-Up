# Constr Up | Gestão de produtos

Front-end em **Vue 3 + Vite**, separado da API Laravel/MySQL. Interface em português para listar, cadastrar, editar e excluir produtos.

O projeto consome uma API real. Os dados persistem no MySQL do projeto **constr-up-api**.

## O que está incluído

- Cadastro e edição dos cinco campos: nome, descrição, marca, preço e estoque.
- Confirmação antes da exclusão.
- Busca por nome ou marca, filtros de estoque, ordenação e paginação.
- Resumo com quantidade de produtos, unidades, valor em estoque e itens com estoque baixo.
- Estados de carregamento, catálogo vazio, busca sem resultados e falha da API.
- Validação de campos e exibição dos erros enviados pelo Laravel.
- Bloqueio de envios repetidos e cancelamento de buscas antigas.
- Layout para computador e celular; a tabela permite rolagem horizontal em telas pequenas.
- Formulários com rótulos, controle de foco e navegação por teclado.

## Requisitos

- Node.js **22.18+ na linha 22**, ou **24.12+**. Recomendado: Node 24.
- npm.
- A API **constr-up-api** em execução.

Confira:

~~~bash
node --version
npm --version
~~~

## Instalar e executar

Extraia o projeto e abra um terminal **dentro da pasta constr-up-web**.

~~~bash
npm ci
~~~

Copie a configuração no Linux, macOS ou Git Bash:

~~~bash
cp .env.example .env
~~~

No PowerShell do Windows:

~~~powershell
Copy-Item .env.example .env
~~~

O .env deve apontar para a API:

~~~dotenv
VITE_API_BASE_URL=http://127.0.0.1:8000/api
~~~

Inicie o projeto:

~~~bash
npm run dev
~~~

Abra **http://127.0.0.1:5173**.

O back-end e seu MySQL devem estar ligados. O endereço /api faz parte da configuração; não remova esse trecho.

A porta 5173 é fixa durante o desenvolvimento para coincidir com o CORS da API. Se estiver ocupada, feche a outra aplicação ou ajuste o Vite e as origens permitidas no back-end.

## Usar a interface

1. Clique em **Novo produto**.
2. Preencha nome, marca, descrição, preço e estoque.
3. Use um preço como **34,90** ou **34.90**, sem separador de milhares.
4. Clique em **Salvar produto**.
5. Use o ícone de edição na linha para alterar os dados.
6. Use o ícone da lixeira para abrir a confirmação de exclusão.

O estoque aceita apenas unidades inteiras. Produtos com 1 a 5 unidades aparecem como **Estoque baixo**; com zero, **Sem estoque**. O card de atenção reúne os dois casos.

Os cards resumem **todo o catálogo**; os filtros afetam a tabela. Ao cadastrar um item com filtros ativos, ele poderá não aparecer na lista até que os filtros sejam limpos.

## Scripts

| Comando | Finalidade |
| --- | --- |
| npm run dev | Servidor de desenvolvimento |
| npm run build | Gera os arquivos de produção em dist |
| npm run preview | Visualiza o build em http://127.0.0.1:4173 |
| npm test | Executa os testes de validação, formulário e HTTP |
| npm run test:watch | Executa os testes durante a edição |
| npm run test:e2e | Testa o fluxo completo com API e navegador |
| npm run format | Formata o código com Prettier |
| npm run format:check | Verifica a formatação |

## Testes

Os testes unitários e de componentes não dependem de uma API ligada:

~~~bash
npm test
npm run build
~~~

Para os testes de integração com navegador, primeiro inicie a API e o MySQL de desenvolvimento. Depois:

~~~bash
npx playwright install chromium
npm run test:e2e
~~~

O Playwright inicia o Vite automaticamente quando necessário. Testa cadastro, busca, edição, cancelamento e confirmação da exclusão em um viewport de computador e outro de celular, ambos usando Chromium.

Cada execução cria um produto de nome E2E-..., e tenta removê-lo ao terminar. Use um banco local de desenvolvimento. Os testes não dependem dos produtos do seed.

Se a API usar outro endereço, ajuste o .env e defina **E2E_API_URL** para esse mesmo endereço ao executar o teste. No PowerShell:

~~~powershell
$env:E2E_API_URL="http://127.0.0.1:8001/api"
npm run test:e2e
~~~

O workflow **.github/workflows/ci.yml** executa testes unitários, verificação de formatação e build. Os testes com navegador exigem a API separada, portanto são executados localmente.

## Estrutura

| Arquivo | Responsabilidade |
| --- | --- |
| src/App.vue | Tela, busca, paginação e coordenação do CRUD |
| src/components/ProductForm.vue | Formulário e validação de entrada |
| src/components/BaseDialog.vue | Modal acessível e gerenciamento de foco |
| src/components/AppIcon.vue | Ícones SVG |
| src/services/api.js | Requisições HTTP e mensagens de erro |
| src/lib/format.js | Moeda, estoque e normalização dos valores |
| src/style.css | Estilos e adaptação para telas pequenas |
| src/**/*.test.js | Testes unitários e de componentes |
| tests/e2e/products.spec.js | Fluxo completo com a API |

O projeto utiliza Composition API e componentes Single File. O cliente HTTP usa fetch nativo. O preço é enviado como string decimal para preservar os centavos; a interface formata a exibição em reais.

## Build para publicação

~~~bash
npm run build
~~~

Os arquivos gerados ficam em **dist/**. Configure VITE_API_BASE_URL **antes do build**: as variáveis VITE_ são incorporadas ao JavaScript e ficam públicas.

A API precisa estar acessível ao navegador que abrir o site. Em uma instalação pública, um endereço 127.0.0.1 não aponta para o servidor remoto. Configure o domínio real da API e a origem correspondente no CORS do Laravel.

## Publicar no GitHub

Crie um repositório **público e vazio**, chamado **constr-up-web**. Dentro desta pasta, substitua **SEU_USUARIO**:

~~~bash
git init -b main
git add .
git commit -m "Implementa interface Vue para o catálogo de produtos"
git remote add origin https://github.com/SEU_USUARIO/constr-up-web.git
git push -u origin main
~~~

O .gitignore exclui .env, node_modules, dist e resultados dos testes. O package-lock.json deve permanecer versionado para que npm ci reproduza as dependências.

Entregue o link deste repositório junto com o link do **constr-up-api**. Os dois devem ser públicos, conforme o enunciado.

## Problemas comuns

- **Não foi possível conectar ao servidor:** confirme se a API está rodando e abra http://127.0.0.1:8000/api/products no navegador.
- **Erro de CORS:** confira CORS_ALLOWED_ORIGINS no Laravel, execute php artisan config:clear e reinicie a API.
- **Mudança de .env não apareceu:** reinicie o Vite; para produção, gere um novo build.
- **Node incompatível:** use a versão informada em .nvmrc ou uma versão compatível indicada nos requisitos.
- **EADDRINUSE:** a porta 5173 já está em uso.
- **Navegador do Playwright ausente:** execute npx playwright install chromium.

## Referências

- [Guia oficial do Vue](https://vuejs.org/guide/)
- [Documentação do Vite](https://vite.dev/guide/)
