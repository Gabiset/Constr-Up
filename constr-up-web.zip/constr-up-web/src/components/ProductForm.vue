<script setup>
import { computed, nextTick, reactive, ref } from "vue";
import { normalizePrice, validateProduct } from "../lib/format";
import BaseDialog from "./BaseDialog.vue";
import AppIcon from "./AppIcon.vue";

const props = defineProps({
  product: { type: Object, default: null },
  busy: Boolean,
  serverErrors: { type: Object, default: () => ({}) },
  error: String,
});
const emit = defineEmits(["save", "close"]);
const formEl = ref(null);
const values = reactive({
  name: props.product?.name ?? "",
  brand: props.product?.brand ?? "",
  description: props.product?.description ?? "",
  price: props.product ? String(props.product.price).replace(".", ",") : "",
  stock: props.product?.stock ?? "",
});
const localErrors = ref({});
const errors = computed(() => {
  const normalized = Object.fromEntries(
    Object.entries(props.serverErrors).map(([key, messages]) => [
      key,
      Array.isArray(messages) ? messages[0] : messages,
    ]),
  );
  return { ...normalized, ...localErrors.value };
});
async function submit() {
  if (props.busy) return;
  localErrors.value = validateProduct(values);
  if (Object.keys(localErrors.value).length) {
    await nextTick();
    formEl.value.querySelector('[aria-invalid="true"]')?.focus();
    return;
  }
  emit("save", {
    name: values.name.trim(),
    brand: values.brand.trim(),
    description: values.description.trim(),
    price: normalizePrice(values.price),
    stock: Number(values.stock),
  });
}
</script>

<template>
  <BaseDialog
    :title="product ? 'Editar produto' : 'Novo produto'"
    :subtitle="
      product
        ? 'Atualize as informações do seu catálogo.'
        : 'Preencha os dados para adicionar ao catálogo.'
    "
    :busy="busy"
    @close="emit('close')"
  >
    <form ref="formEl" novalidate @submit.prevent="submit">
      <div class="dialog-body">
        <div v-if="error" class="alert error" role="alert">{{ error }}</div>
        <p class="form-hint">Todos os campos são obrigatórios.</p>
        <div class="field">
          <label for="name">Nome do produto</label
          ><input
            id="name"
            v-model="values.name"
            name="name"
            autofocus
            maxlength="150"
            placeholder="Ex.: Cimento CP II 50 kg"
            :disabled="busy"
            :aria-invalid="!!errors.name"
            :aria-describedby="errors.name ? 'name-error' : undefined"
          /><span v-if="errors.name" id="name-error" class="field-error">{{
            errors.name
          }}</span>
        </div>
        <div class="field">
          <label for="brand">Marca</label
          ><input
            id="brand"
            v-model="values.brand"
            name="brand"
            maxlength="100"
            placeholder="Ex.: Votoran"
            :disabled="busy"
            :aria-invalid="!!errors.brand"
            :aria-describedby="errors.brand ? 'brand-error' : undefined"
          /><span v-if="errors.brand" id="brand-error" class="field-error">{{
            errors.brand
          }}</span>
        </div>
        <div class="field">
          <label for="description">Descrição</label
          ><textarea
            id="description"
            v-model="values.description"
            name="description"
            maxlength="2000"
            rows="3"
            placeholder="Descreva as características do produto"
            :disabled="busy"
            :aria-invalid="!!errors.description"
            :aria-describedby="
              errors.description ? 'description-error' : undefined
            "
          ></textarea
          ><span
            v-if="errors.description"
            id="description-error"
            class="field-error"
            >{{ errors.description }}</span
          >
        </div>
        <div class="field-grid">
          <div class="field">
            <label for="price">Preço unitário (R$)</label
            ><input
              id="price"
              v-model="values.price"
              name="price"
              inputmode="decimal"
              placeholder="0,00"
              :disabled="busy"
              :aria-invalid="!!errors.price"
              :aria-describedby="errors.price ? 'price-error' : undefined"
            /><span v-if="errors.price" id="price-error" class="field-error">{{
              errors.price
            }}</span>
          </div>
          <div class="field">
            <label for="stock">Estoque (unidades)</label
            ><input
              id="stock"
              v-model="values.stock"
              name="stock"
              inputmode="numeric"
              placeholder="0"
              :disabled="busy"
              :aria-invalid="!!errors.stock"
              :aria-describedby="errors.stock ? 'stock-error' : undefined"
            /><span v-if="errors.stock" id="stock-error" class="field-error">{{
              errors.stock
            }}</span>
          </div>
        </div>
      </div>
      <footer class="dialog-footer">
        <button
          class="button secondary"
          type="button"
          :disabled="busy"
          @click="emit('close')"
        >
          Cancelar</button
        ><button class="button primary" type="submit" :disabled="busy">
          <AppIcon v-if="!busy" name="check" />{{
            busy ? "Salvando…" : "Salvar produto"
          }}
        </button>
      </footer>
    </form>
  </BaseDialog>
</template>
