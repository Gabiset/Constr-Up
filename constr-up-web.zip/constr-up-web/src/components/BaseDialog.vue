<script setup>
import { nextTick, onBeforeUnmount, onMounted, ref } from "vue";
import AppIcon from "./AppIcon.vue";

const props = defineProps({
  title: String,
  subtitle: String,
  busy: Boolean,
  danger: Boolean,
});
const emit = defineEmits(["close"]);
const dialog = ref(null);
let previousFocus;
let previousOverflow;

function close() {
  if (!props.busy) emit("close");
}
function onKeydown(event) {
  if (event.key === "Escape") {
    event.preventDefault();
    close();
    return;
  }
  if (event.key !== "Tab") return;
  const focusables = [
    ...dialog.value.querySelectorAll(
      'button:not(:disabled), input:not(:disabled), textarea:not(:disabled), select:not(:disabled), [tabindex="0"]',
    ),
  ];
  const first = focusables[0];
  const last = focusables.at(-1);
  if (!first) {
    event.preventDefault();
    dialog.value.focus();
    return;
  }
  if (
    event.shiftKey &&
    (document.activeElement === first ||
      document.activeElement === dialog.value)
  ) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

onMounted(async () => {
  previousFocus = document.activeElement;
  previousOverflow = document.body.style.overflow;
  document.body.style.overflow = "hidden";
  await nextTick();
  (dialog.value.querySelector("[autofocus]") || dialog.value).focus();
});
onBeforeUnmount(() => {
  document.body.style.overflow = previousOverflow;
  previousFocus?.focus();
});
</script>

<template>
  <Teleport to="body">
    <div class="dialog-backdrop" @click.self="close">
      <section
        ref="dialog"
        class="dialog"
        :class="{ 'dialog-danger': danger }"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
        :aria-describedby="subtitle ? 'dialog-subtitle' : undefined"
        :aria-busy="busy"
        tabindex="-1"
        @keydown="onKeydown"
      >
        <header class="dialog-heading">
          <div>
            <span class="eyebrow">CATÁLOGO DE PRODUTOS</span>
            <h2 id="dialog-title">{{ title }}</h2>
            <p v-if="subtitle" id="dialog-subtitle">{{ subtitle }}</p>
          </div>
          <button
            type="button"
            class="icon-button"
            aria-label="Fechar janela"
            :disabled="busy"
            @click="close"
          >
            <AppIcon name="close" />
          </button>
        </header>
        <slot />
      </section>
    </div>
  </Teleport>
</template>
