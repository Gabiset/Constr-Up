import { afterEach, describe, expect, it } from "vitest";
import { mount } from "@vue/test-utils";
import ProductForm from "./ProductForm.vue";

let wrapper;
afterEach(() => {
  wrapper?.unmount();
  document.body.innerHTML = "";
});
const mountForm = (props = {}) => {
  wrapper = mount(ProductForm, {
    props,
    attachTo: document.body,
    global: { stubs: { Teleport: true } },
  });
  return wrapper;
};

describe("Formulário de produto", () => {
  it("impede envio vazio e apresenta os campos obrigatórios", async () => {
    mountForm();
    await wrapper.find("form").trigger("submit");
    expect(wrapper.emitted("save")).toBeUndefined();
    expect(wrapper.findAll('[aria-invalid="true"]')).toHaveLength(5);
  });
  it("envia os dados normalizados para a API", async () => {
    mountForm();
    for (const [field, value] of Object.entries({
      name: "  Cimento  ",
      brand: " Votoran ",
      description: " Saco de 50 kg ",
      price: "32,9",
      stock: "10",
    })) {
      await wrapper.find(`#${field}`).setValue(value);
    }
    await wrapper.find("form").trigger("submit");
    expect(wrapper.emitted("save")[0][0]).toEqual({
      name: "Cimento",
      brand: "Votoran",
      description: "Saco de 50 kg",
      price: "32.90",
      stock: 10,
    });
  });
  it("preenche a edição e bloqueia envio duplicado durante a gravação", async () => {
    mountForm({
      product: {
        id: 1,
        name: "Tinta",
        brand: "Coral",
        description: "Branca",
        price: "25.90",
        stock: 0,
      },
      busy: true,
    });
    expect(wrapper.find("#price").element.value).toBe("25,90");
    expect(wrapper.find("#stock").element.value).toBe("0");
    await wrapper.find("form").trigger("submit");
    expect(wrapper.emitted("save")).toBeUndefined();
    expect(
      wrapper.find('[type="submit"]').attributes("disabled"),
    ).toBeDefined();
  });
  it("apresenta erros de validação recebidos do servidor", () => {
    mountForm({
      serverErrors: { name: ["O nome é obrigatório."] },
      error: "Revise os dados.",
    });
    expect(wrapper.find("#name-error").text()).toBe("O nome é obrigatório.");
    expect(wrapper.find('[role="alert"]').text()).toBe("Revise os dados.");
  });
});
