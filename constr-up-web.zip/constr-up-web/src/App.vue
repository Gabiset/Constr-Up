<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from "vue";
import AppIcon from "./components/AppIcon.vue";
import BaseDialog from "./components/BaseDialog.vue";
import ProductForm from "./components/ProductForm.vue";
import { productsApi } from "./services/api";
import {
  formatCurrency,
  formatNumber,
  stockClass,
  stockLabel,
} from "./lib/format";

const products = ref([]);
const stats = ref(null);
const meta = ref({ total: 0, last_page: 1, from: null, to: null });
const page = ref(1);
const perPage = ref(12);
const search = ref("");
const stockFilter = ref("all");
const sort = ref("newest");
const loading = ref(true);
const listError = ref("");
const toast = ref("");
const showForm = ref(false);
const editingProduct = ref(null);
const deletingProduct = ref(null);
const submitting = ref(false);
const formError = ref("");
const formErrors = ref({});
const deleteError = ref("");
let activeController;
let requestId = 0;
let searchTimer;
let toastTimer;
const hasFilters = computed(
  () => search.value.trim() !== "" || stockFilter.value !== "all",
);

async function loadProducts() {
  activeController?.abort();
  const controller = new AbortController();
  activeController = controller;
  const id = ++requestId;
  loading.value = true;
  listError.value = "";
  try {
    const result = await productsApi.list(
      {
        page: String(page.value),
        per_page: String(perPage.value),
        search: search.value.trim(),
        stock: stockFilter.value,
        sort: sort.value,
      },
      controller.signal,
    );
    if (id !== requestId) return;
    if (page.value > result.meta.last_page) {
      page.value = Math.max(1, result.meta.last_page);
      return await loadProducts();
    }
    products.value = result.data;
    meta.value = result.meta;
    stats.value = result.stats;
  } catch (error) {
    if (id === requestId && !controller.signal.aborted)
      listError.value = error.message;
  } finally {
    if (id === requestId) loading.value = false;
  }
}

watch([search, stockFilter, sort, perPage], (current, previous) => {
  clearTimeout(searchTimer);
  activeController?.abort();
  page.value = 1;
  searchTimer = setTimeout(loadProducts, current[0] !== previous[0] ? 300 : 0);
});
function goPage(value) {
  page.value = value;
  loadProducts();
}
function notify(message) {
  clearTimeout(toastTimer);
  toast.value = message;
  toastTimer = setTimeout(() => {
    toast.value = "";
  }, 6000);
}
function openForm(product = null) {
  editingProduct.value = product;
  formErrors.value = {};
  formError.value = "";
  showForm.value = true;
}
async function saveProduct(data) {
  if (submitting.value) return;
  submitting.value = true;
  formError.value = "";
  formErrors.value = {};
  try {
    const editing = Boolean(editingProduct.value);
    if (editing) await productsApi.update(editingProduct.value.id, data);
    else await productsApi.create(data);
    showForm.value = false;
    notify(
      editing
        ? "Produto atualizado com sucesso."
        : "Produto cadastrado com sucesso.",
    );
    if (!editing) page.value = 1;
    await loadProducts();
  } catch (error) {
    formError.value = error.message;
    formErrors.value = error.errors || {};
  } finally {
    submitting.value = false;
  }
}
function confirmDelete(product) {
  deleteError.value = "";
  deletingProduct.value = product;
}
async function removeProduct() {
  if (submitting.value || !deletingProduct.value) return;
  submitting.value = true;
  deleteError.value = "";
  try {
    await productsApi.remove(deletingProduct.value.id);
    deletingProduct.value = null;
    notify("Produto excluído com sucesso.");
    if (products.value.length === 1 && page.value > 1) page.value--;
    await loadProducts();
  } catch (error) {
    deleteError.value = error.message;
  } finally {
    submitting.value = false;
  }
}
function clearFilters() {
  search.value = "";
  stockFilter.value = "all";
}
onMounted(loadProducts);
onBeforeUnmount(() => {
  activeController?.abort();
  clearTimeout(searchTimer);
  clearTimeout(toastTimer);
});
</script>

<template>
  <a class="skip-link" href="#main-content">Ir para o conteúdo</a>
  <div class="app-layout" :inert="showForm || !!deletingProduct">
    <aside class="sidebar" aria-label="Navegação do catálogo">
      <a class="brand" href="/" aria-label="Constr Up, início"
        ><span class="brand-symbol"><AppIcon name="stack" :size="23" /></span
        ><span>constr<span class="brand-up">up.</span></span></a
      >
      <div class="sidebar-section-label">GESTÃO DO CATÁLOGO</div>
      <nav class="navigation">
        <button
          :class="{
            active: stockFilter === 'all' || stockFilter === 'available',
          }"
          :aria-current="
            stockFilter === 'all' || stockFilter === 'available'
              ? 'page'
              : undefined
          "
          @click="
            stockFilter = 'all';
            search = '';
          "
        >
          <AppIcon name="box" /><span>Todos os produtos</span
          ><span v-if="stats" class="nav-count">{{
            stats.total_products
          }}</span>
        </button>
        <button
          :class="{ active: stockFilter === 'low' }"
          :aria-current="stockFilter === 'low' ? 'page' : undefined"
          @click="stockFilter = 'low'"
        >
          <AppIcon name="warning" /><span>Estoque baixo</span
          ><span v-if="stats" class="nav-count">{{ stats.low_stock }}</span>
        </button>
        <button
          :class="{ active: stockFilter === 'empty' }"
          :aria-current="stockFilter === 'empty' ? 'page' : undefined"
          @click="stockFilter = 'empty'"
        >
          <AppIcon name="stack" /><span>Sem estoque</span
          ><span v-if="stats" class="nav-count">{{ stats.out_of_stock }}</span>
        </button>
      </nav>
      <div class="sidebar-note">
        <span class="small-dot"></span>
        <h3>Seu estoque em dia.</h3>
        <p>Produtos com até 5 unidades merecem uma atenção especial.</p>
      </div>
      <div class="sidebar-footer">
        <span class="brand-symbol small"
          ><AppIcon name="box" :size="17"
        /></span>
        <div><strong>Constr Up</strong><span>Gestão de produtos</span></div>
      </div>
    </aside>

    <div class="workspace">
      <header class="topbar">
        <div class="breadcrumb">
          Catálogo <AppIcon name="chevron" :size="13" /><strong
            >Produtos</strong
          >
        </div>
        <div class="workspace-label">
          <span class="small-dot"></span>Controle de estoque
        </div>
      </header>
      <main id="main-content" tabindex="-1">
        <section class="page-heading">
          <div>
            <span class="eyebrow">ORGANIZE. ACOMPANHE. CONSTRUA.</span>
            <h1>Seus produtos<span>.</span></h1>
            <p>O catálogo completo, com tudo no lugar.</p>
          </div>
          <button
            class="button primary"
            :disabled="submitting"
            @click="openForm()"
          >
            <AppIcon name="plus" />Novo produto
          </button>
        </section>

        <section class="stats" aria-label="Resumo de todo o catálogo">
          <article class="stat-card">
            <div class="stat-top">
              <span>Produtos cadastrados</span><AppIcon name="box" />
            </div>
            <strong>{{
              stats ? formatNumber(stats.total_products) : "—"
            }}</strong>
            <p>Itens no seu catálogo</p>
          </article>
          <article class="stat-card">
            <div class="stat-top">
              <span>Unidades em estoque</span><AppIcon name="stack" />
            </div>
            <strong>{{ stats ? formatNumber(stats.total_units) : "—" }}</strong>
            <p>Soma de todos os produtos</p>
          </article>
          <article class="stat-card">
            <div class="stat-top">
              <span>Valor em estoque</span><AppIcon name="coin" />
            </div>
            <strong class="stat-currency">{{
              stats ? formatCurrency(stats.total_value) : "—"
            }}</strong>
            <p>Preço unitário × quantidade</p>
          </article>
          <article class="stat-card attention">
            <div class="stat-top">
              <span>Precisam de atenção</span><AppIcon name="warning" />
            </div>
            <strong>{{
              stats ? formatNumber(stats.low_stock + stats.out_of_stock) : "—"
            }}</strong>
            <p>Produtos com até 5 unidades</p>
          </article>
        </section>

        <section
          class="catalog"
          aria-labelledby="catalog-title"
          :aria-busy="loading"
        >
          <div class="catalog-title-row">
            <div>
              <h2 id="catalog-title">Catálogo de produtos</h2>
              <span class="catalog-count"
                >{{ formatNumber(meta.total) }}
                {{
                  meta.total === 1
                    ? "produto encontrado"
                    : "produtos encontrados"
                }}</span
              >
            </div>
            <button
              class="icon-button refresh-button"
              :disabled="loading"
              aria-label="Atualizar produtos"
              title="Atualizar produtos"
              @click="loadProducts"
            >
              <AppIcon name="refresh" :class="{ spinning: loading }" />
            </button>
          </div>
          <div class="toolbar">
            <div class="search-field">
              <AppIcon name="search" :size="18" /><label
                for="search"
                class="sr-only"
                >Buscar produtos</label
              ><input
                id="search"
                v-model="search"
                maxlength="120"
                placeholder="Buscar por nome ou marca…"
                type="search"
                autocomplete="off"
              />
            </div>
            <div class="filter-field">
              <label for="stock-filter" class="sr-only"
                >Filtrar por estoque</label
              ><select id="stock-filter" v-model="stockFilter">
                <option value="all">Todos os estoques</option>
                <option value="available">Em estoque</option>
                <option value="low">Estoque baixo (1 a 5)</option>
                <option value="empty">Sem estoque</option>
              </select>
            </div>
            <div class="filter-field">
              <label for="sort" class="sr-only">Ordenar produtos</label
              ><select id="sort" v-model="sort">
                <option value="newest">Mais recentes</option>
                <option value="name">Nome: A a Z</option>
                <option value="price_asc">Menor preço</option>
                <option value="price_desc">Maior preço</option>
                <option value="stock">Menor estoque</option>
              </select>
            </div>
          </div>

          <div v-if="listError" class="empty-state" role="alert">
            <div class="empty-icon error-icon">
              <AppIcon name="warning" :size="30" />
            </div>
            <h3>Não foi possível carregar os produtos</h3>
            <p>{{ listError }}</p>
            <button class="button secondary" @click="loadProducts">
              <AppIcon name="refresh" />Tentar novamente
            </button>
          </div>
          <div v-else-if="loading" class="loading-state" role="status">
            <div v-for="line in 5" :key="line" class="skeleton-row">
              <span></span><span></span><span></span><span></span>
            </div>
            <span class="sr-only">Carregando produtos…</span>
          </div>
          <div v-else-if="!products.length" class="empty-state">
            <div class="empty-icon"><AppIcon name="box" :size="32" /></div>
            <h3>
              {{
                hasFilters
                  ? "Nenhum produto encontrado"
                  : "Seu catálogo começa aqui"
              }}
            </h3>
            <p>
              {{
                hasFilters
                  ? "Tente outro nome, marca ou filtro de estoque."
                  : "Cadastre o primeiro produto e comece a organizar seu estoque."
              }}
            </p>
            <button
              v-if="hasFilters"
              class="button secondary"
              @click="clearFilters"
            >
              Limpar filtros</button
            ><button v-else class="button primary" @click="openForm()">
              <AppIcon name="plus" />Cadastrar primeiro produto
            </button>
          </div>
          <div v-else class="table-wrapper">
            <table>
              <caption class="sr-only">
                Produtos, marcas, preços e quantidades disponíveis
              </caption>
              <thead>
                <tr>
                  <th scope="col">Produto</th>
                  <th scope="col">Marca</th>
                  <th scope="col" class="text-right">Preço unitário</th>
                  <th scope="col" class="text-right">Estoque</th>
                  <th scope="col">Status</th>
                  <th scope="col" class="text-right">Ações</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="product in products" :key="product.id">
                  <td>
                    <div class="product-cell">
                      <span class="product-icon"
                        ><AppIcon name="box" :size="21"
                      /></span>
                      <div class="product-info">
                        <strong>{{ product.name }}</strong>
                        <p :title="product.description">
                          {{ product.description }}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span class="brand-tag">{{ product.brand }}</span>
                  </td>
                  <td class="text-right price-cell">
                    {{ formatCurrency(product.price) }}
                  </td>
                  <td class="text-right stock-cell">
                    {{ formatNumber(product.stock) }} <span>un.</span>
                  </td>
                  <td>
                    <span
                      class="status-badge"
                      :class="stockClass(product.stock)"
                      ><span></span>{{ stockLabel(product.stock) }}</span
                    >
                  </td>
                  <td>
                    <div class="row-actions">
                      <button
                        class="icon-button"
                        :aria-label="`Editar ${product.name}`"
                        title="Editar produto"
                        :disabled="submitting"
                        @click="openForm(product)"
                      >
                        <AppIcon name="edit" :size="17" /></button
                      ><button
                        class="icon-button danger-button"
                        :aria-label="`Excluir ${product.name}`"
                        title="Excluir produto"
                        :disabled="submitting"
                        @click="confirmDelete(product)"
                      >
                        <AppIcon name="trash" :size="17" />
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <footer
            v-if="!listError && !loading && products.length"
            class="pagination"
          >
            <span
              >Exibindo <strong>{{ meta.from }}–{{ meta.to }}</strong> de
              <strong>{{ formatNumber(meta.total) }}</strong> produtos</span
            >
            <div class="pagination-actions">
              <label class="per-page-label" for="per-page">Por página</label
              ><select id="per-page" v-model.number="perPage">
                <option :value="12">12</option>
                <option :value="24">24</option>
                <option :value="48">48</option></select
              ><button
                class="icon-button"
                aria-label="Página anterior"
                :disabled="page <= 1"
                @click="goPage(page - 1)"
              >
                <AppIcon name="chevron" class="rotate" :size="17" /></button
              ><span class="page-number">{{ page }} / {{ meta.last_page }}</span
              ><button
                class="icon-button"
                aria-label="Próxima página"
                :disabled="page >= meta.last_page"
                @click="goPage(page + 1)"
              >
                <AppIcon name="chevron" :size="17" />
              </button>
            </div>
          </footer>
        </section>
        <footer class="page-footer">
          <span>CONSTR UP</span>
          <p>Uma base organizada para construir mais.</p>
        </footer>
      </main>
    </div>
  </div>

  <div class="toast-container" aria-live="polite">
    <div v-if="toast" class="toast">
      <AppIcon name="check" /><span>{{ toast }}</span
      ><button
        class="icon-button"
        aria-label="Fechar notificação"
        @click="toast = ''"
      >
        <AppIcon name="close" :size="16" />
      </button>
    </div>
  </div>
  <ProductForm
    v-if="showForm"
    :product="editingProduct"
    :busy="submitting"
    :server-errors="formErrors"
    :error="formError"
    @close="showForm = false"
    @save="saveProduct"
  />
  <BaseDialog
    v-if="deletingProduct"
    title="Excluir produto?"
    subtitle="Confira o item antes de continuar."
    :busy="submitting"
    danger
    @close="deletingProduct = null"
    ><div class="dialog-body">
      <div v-if="deleteError" class="alert error" role="alert">
        {{ deleteError }}
      </div>
      <div class="delete-product">
        <span class="empty-icon error-icon"
          ><AppIcon name="trash" :size="26"
        /></span>
        <div>
          <strong>{{ deletingProduct.name }}</strong>
          <p>{{ deletingProduct.brand }}</p>
        </div>
      </div>
      <p class="delete-notice">
        O produto será removido permanentemente do catálogo. Esta ação não pode
        ser desfeita.
      </p>
    </div>
    <footer class="dialog-footer">
      <button
        class="button secondary"
        autofocus
        :disabled="submitting"
        @click="deletingProduct = null"
      >
        Cancelar</button
      ><button
        class="button danger"
        :disabled="submitting"
        @click="removeProduct"
      >
        <AppIcon v-if="!submitting" name="trash" :size="17" />{{
          submitting ? "Excluindo…" : "Excluir produto"
        }}
      </button>
    </footer></BaseDialog
  >
</template>
