import { afterEach, describe, expect, it, vi } from "vitest";
import { productsApi, request } from "./api";

afterEach(() => vi.unstubAllGlobals());

describe("Integração HTTP", () => {
  it("envia JSON e aceita uma criação com status 201", async () => {
    const fetch = vi
      .fn()
      .mockResolvedValue(
        new Response(JSON.stringify({ data: { id: 1 } }), { status: 201 }),
      );
    vi.stubGlobal("fetch", fetch);
    expect(await productsApi.create({ name: "Produto" })).toEqual({
      data: { id: 1 },
    });
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining("/api/products"),
      expect.objectContaining({
        method: "POST",
        body: '{"name":"Produto"}',
        headers: expect.objectContaining({
          Accept: "application/json",
          "Content-Type": "application/json",
        }),
      }),
    );
  });
  it("aceita exclusão 204 sem tentar interpretar um corpo JSON", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(null, { status: 204 })),
    );
    expect(await productsApi.remove(1)).toBeNull();
  });
  it("preserva os erros de campo devolvidos pela API", async () => {
    const errors = { price: ["O preço não pode ser negativo."] };
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValue(
          new Response(
            JSON.stringify({ message: "Revise os dados.", errors }),
            { status: 422 },
          ),
        ),
    );
    await expect(productsApi.create({})).rejects.toMatchObject({
      status: 422,
      errors,
    });
  });
  it("exibe uma mensagem compreensível quando o servidor está indisponível", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockRejectedValue(new TypeError("Failed to fetch")),
    );
    await expect(request("/products")).rejects.toThrow(
      "Não foi possível conectar ao servidor.",
    );
  });
  it("trata respostas HTML de erro sem expor o conteúdo", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValue(
          new Response("<h1>Erro interno</h1>", { status: 500 }),
        ),
    );
    await expect(request("/products")).rejects.toMatchObject({
      status: 500,
      message: "O servidor não conseguiu concluir a operação. Tente novamente.",
    });
  });
});
