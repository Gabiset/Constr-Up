export class ApiError extends Error {
  constructor(message, status = 0, errors = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.errors = errors;
  }
}

const baseUrl = (
  import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000/api"
).replace(/\/$/, "");

export async function request(path, { signal, ...options } = {}) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) abort();
  let timedOut = false;
  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 15000);

  try {
    const response = await fetch(`${baseUrl}${path}`, {
      ...options,
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
    });
    if (response.status === 204) return null;
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      const fallback =
        response.status >= 500
          ? "O servidor não conseguiu concluir a operação. Tente novamente."
          : "Não foi possível concluir a operação.";
      throw new ApiError(
        data?.message || fallback,
        response.status,
        data?.errors || {},
      );
    }
    if (!data)
      throw new ApiError(
        "O servidor enviou uma resposta inválida.",
        response.status,
      );
    return data;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (signal?.aborted) throw error;
    if (timedOut)
      throw new ApiError("O servidor demorou para responder. Tente novamente.");
    throw new ApiError(
      "Não foi possível conectar ao servidor. Verifique se a API está em execução.",
    );
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener("abort", abort);
  }
}

export const productsApi = {
  list: (params, signal) =>
    request(`/products?${new URLSearchParams(params)}`, { signal }),
  create: (data) =>
    request("/products", { method: "POST", body: JSON.stringify(data) }),
  update: (id, data) =>
    request(`/products/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  remove: (id) => request(`/products/${id}`, { method: "DELETE" }),
};
