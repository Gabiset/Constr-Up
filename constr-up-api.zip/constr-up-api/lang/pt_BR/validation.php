<?php

return [
    'required' => 'O campo :attribute é obrigatório.',
    'string' => 'O campo :attribute deve ser um texto.',
    'numeric' => 'O campo :attribute deve ser um número.',
    'integer' => 'O campo :attribute deve ser um número inteiro.',
    'in' => 'O valor selecionado para :attribute é inválido.',
    'min' => ['numeric' => 'O campo :attribute deve ser no mínimo :min.'],
    'max' => [
        'numeric' => 'O campo :attribute deve ser no máximo :max.',
        'string' => 'O campo :attribute deve ter no máximo :max caracteres.',
    ],
    'between' => ['numeric' => 'O campo :attribute deve estar entre :min e :max.'],
    'regex' => 'O formato do campo :attribute é inválido.',
    'attributes' => [],
];
