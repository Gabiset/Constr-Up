# Constr Up | API de produtos

API REST em **Laravel 13 + MySQL** para o teste técnico Constr Up. Este é o projeto de back-end; a interface Vue está em um projeto separado, chamado **constr-up-web**.

Implementa listagem, criação, consulta, edição e exclusão de produtos com **nome, descrição, marca, preço e estoque**. Inclui validação em português, paginação, busca por nome ou marca, filtros de estoque, ordenação, resumo do catálogo e testes automatizados.

## Requisitos

- PHP **8.3 ou superior**, compatível com o Laravel 13.
- Composer 2.
- Extensões PHP: PDO, pdo_mysql, mbstring, DOM/XML, ctype, curl, fileinfo, filter, hash, openssl, pcre, session e tokenizer. ZIP facilita a instalação. Para os testes padrão, habilite pdo_sqlite.
- MySQL **8.0 ou 8.4**. Opcionalmente, Docker com Compose v2 para iniciar apenas o banco.

Confira as versões com:

~~~bash
php -v
composer --version
~~~

O back-end não precisa de Node.js.

## 1. Instalar

Extraia o arquivo deste projeto e abra um terminal **dentro da pasta constr-up-api**.

~~~bash
composer install
~~~

Copie o arquivo de configuração. No Linux, macOS ou Git Bash:

~~~bash
cp .env.example .env
~~~

No PowerShell do Windows, use:

~~~powershell
Copy-Item .env.example .env
~~~

Depois:

~~~bash
php artisan key:generate
~~~

Não execute "composer create-project": a aplicação já está completa neste repositório. O comando "composer install" instala as versões registradas no composer.lock.

## 2. Preparar o MySQL

Escolha uma das opções a seguir.

### Opção A: banco com Docker

Com o Docker em execução, dentro da pasta do projeto:

~~~bash
docker compose up -d --wait
~~~

O arquivo compose.yaml inicia **somente o MySQL**. PHP e Composer continuam sendo executados no computador. O volume preserva os dados entre reinicializações.

O .env.example já corresponde às credenciais locais de demonstração:

~~~dotenv
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=constr_up
DB_USERNAME=constr_up
DB_PASSWORD=constr_up_local
~~~

Se a porta 3306 estiver ocupada, mude **DB_PORT** no .env para 3307 antes de iniciar o contêiner. O Compose publica a porta configurada e o Laravel passa a usar a mesma porta.

### Opção B: MySQL instalado no computador

Em um cliente MySQL, conectado como administrador, crie um banco e um usuário local:

~~~sql
CREATE DATABASE constr_up
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'constr_up'@'localhost'
  IDENTIFIED BY 'constr_up_local';

GRANT ALL PRIVILEGES ON constr_up.*
  TO 'constr_up'@'localhost';
~~~

Ajuste **DB_HOST, DB_PORT, DB_DATABASE, DB_USERNAME e DB_PASSWORD** no .env para a sua instalação. Se já houver um usuário adequado, use suas credenciais.

## 3. Criar tabelas e iniciar a API

~~~bash
php artisan migrate --seed
php artisan serve --host=127.0.0.1 --port=8000
~~~

Abra: **http://127.0.0.1:8000/api/products**

Mantenha esse terminal aberto e inicie o projeto Vue em outro terminal.

O seed inclui 14 produtos fictícios de demonstração, com valores ilustrativos. Para começar com um catálogo vazio, use **php artisan migrate** sem a opção --seed. Reexecutar o seed não duplica produtos com o mesmo nome e marca nem sobrescreve alterações nesses registros.

## Rotas disponíveis

| Método | Caminho | Operação |
| --- | --- | --- |
| GET | /api/products | Listar |
| POST | /api/products | Cadastrar |
| GET | /api/products/{id} | Consultar um produto |
| PUT | /api/products/{id} | Editar os cinco campos |
| PATCH | /api/products/{id} | Editar campos específicos |
| DELETE | /api/products/{id} | Excluir |

A documentação com campos, exemplos JSON, filtros e códigos HTTP está em [docs/API.md](docs/API.md). Há exemplos executáveis em [docs/requests.http](docs/requests.http).

## Integração com o Vue

O front-end usa **VITE_API_BASE_URL=http://127.0.0.1:8000/api**.

A API permite CORS para localhost e 127.0.0.1 nas portas 5173 e 4173. Para outro endereço, altere **CORS_ALLOWED_ORIGINS** no .env, separando origens por vírgula, e execute:

~~~bash
php artisan config:clear
~~~

CORS controla o acesso de navegadores; não substitui autenticação. O teste implementa uma API sem login. Para uso público com dados reais, acrescente autenticação e autorização, configure HTTPS e defina APP_DEBUG=false.

## Testes

A suíte padrão usa **SQLite em memória**, de forma isolada do banco de desenvolvimento:

~~~bash
composer test
composer lint
~~~

São verificados CRUD, precisão dos centavos, campos obrigatórios, limites, paginação, filtros, ordenação, respostas 404/422, CORS e seed idempotente.

### Executar a mesma suíte com MySQL

A configuração **phpunit.mysql.xml** fixa o nome do banco de testes em **constr_up_test**. Esse banco é exclusivo para testes: suas tabelas podem ser recriadas pela suíte.

Em um cliente MySQL conectado como administrador, crie-o e conceda acesso ao usuário configurado no .env:

~~~sql
CREATE DATABASE constr_up_test
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

GRANT ALL PRIVILEGES ON constr_up_test.*
  TO 'constr_up'@'localhost';
~~~

Se estiver usando o Compose, abra o cliente com:

~~~bash
docker compose exec mysql mysql -u root -p
~~~

Nesse caso, a senha de demonstração do root é **root_local_only** e o usuário criado pela imagem é **'constr_up'@'%'**. Use esse usuário no GRANT em vez de 'constr_up'@'localhost'.

Execute:

~~~bash
composer test:mysql
~~~

O workflow em **.github/workflows/ci.yml** prepara um MySQL isolado e executa as duas configurações quando houver push ou pull request no GitHub.

## Organização

| Caminho | Responsabilidade |
| --- | --- |
| routes/api.php | Rotas REST |
| app/Http/Controllers/ProductController.php | Operações e filtros |
| app/Http/Requests | Validação de entrada |
| app/Http/Resources/ProductResource.php | Formato de saída JSON |
| app/Models/Product.php | Persistência com Eloquent |
| database/migrations | Estrutura da tabela products |
| database/seeders | Dados demonstrativos |
| tests/Feature/ProductApiTest.php | Testes da API |
| config/cors.php | Origens permitidas |

O preço usa DECIMAL(10,2), o estoque usa inteiro não negativo e apenas os cinco campos esperados podem ser gravados. As regras de negócio ficam simples e próximas dos recursos do Laravel, adequadas ao tamanho do teste.

## Publicar como repositório público

Crie um repositório **público e vazio** no GitHub, com o nome **constr-up-api**. Não adicione README pelo site, porque este projeto já inclui um.

Dentro desta pasta, substitua **SEU_USUARIO** pelo seu usuário real:

~~~bash
git init -b main
git add .
git commit -m "Implementa API de produtos com Laravel e MySQL"
git remote add origin https://github.com/SEU_USUARIO/constr-up-api.git
git push -u origin main
~~~

O .gitignore exclui .env, vendor, caches e logs. Versione o código e o composer.lock; as dependências são instaladas pelo avaliador com Composer.

A entrega do teste deve conter o link deste repositório e o link do repositório separado do front-end. Estes arquivos, por si só, não criam repositórios no GitHub.

## Problemas comuns

- **could not find driver:** habilite pdo_mysql no PHP usado pelo terminal; use php --ini para identificar o arquivo de configuração.
- **Connection refused:** confira se o MySQL está ligado e se DB_HOST/DB_PORT correspondem ao serviço.
- **Access denied:** confira usuário, senha e privilégios do MySQL.
- **Unknown database:** crie o banco antes de executar as migrations.
- **No application encryption key:** execute php artisan key:generate.
- **Configuração antiga:** execute php artisan config:clear e reinicie o servidor.
- **Porta 8000 ocupada:** use outra porta no artisan serve e ajuste VITE_API_BASE_URL no projeto Vue.

## Referências

- [Documentação do Laravel 13](https://laravel.com/docs/13.x)
- [Validação no Laravel](https://laravel.com/docs/13.x/validation)
- [API Resources](https://laravel.com/docs/13.x/eloquent-resources)
