<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => response()->json([
    'name' => 'Constr Up - API de produtos',
    'products' => '/api/products',
    'health' => '/up',
]));
