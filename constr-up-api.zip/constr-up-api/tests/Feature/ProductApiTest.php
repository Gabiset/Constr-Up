<?php

namespace Tests\Feature;

use App\Models\Product;
use Database\Seeders\ProductSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class ProductApiTest extends TestCase
{
    use RefreshDatabase;

    private function payload(array $overrides = []): array
    {
        return array_merge([
            'name' => 'Cimento CP II',
            'description' => 'Saco de 50 kg.',
            'brand' => 'Votoran',
            'price' => '34.90',
            'stock' => 10,
        ], $overrides);
    }

    public function test_empty_catalog_returns_valid_pagination_and_zero_stats(): void
    {
        $this->getJson('/api/products')->assertOk()
            ->assertJsonPath('data', [])
            ->assertJsonPath('meta.total', 0)
            ->assertJsonPath('stats.total_products', 0)
            ->assertJsonPath('stats.total_units', 0)
            ->assertJsonPath('stats.low_stock', 0)
            ->assertJsonPath('stats.out_of_stock', 0);
    }

    public function test_it_creates_and_persists_a_product_with_exact_cents(): void
    {
        $response = $this->postJson('/api/products', $this->payload(['price' => '0.10']));
        $response->assertCreated()->assertJsonPath('data.price', '0.10')
            ->assertJsonPath('data.stock', 10)
            ->assertJsonStructure(['data' => ['id', 'name', 'description', 'brand', 'price', 'stock', 'created_at', 'updated_at']]);

        $this->assertDatabaseHas('products', ['id' => $response->json('data.id'), 'name' => 'Cimento CP II', 'price' => '0.10', 'stock' => 10]);
    }

    public function test_it_accepts_zero_price_and_zero_stock(): void
    {
        $this->postJson('/api/products', $this->payload(['price' => '0', 'stock' => 0]))
            ->assertCreated()->assertJsonPath('data.price', '0.00')->assertJsonPath('data.stock', 0);
    }

    public function test_it_does_not_mass_assign_extra_fields(): void
    {
        $response = $this->postJson('/api/products', $this->payload(['id' => 999, 'created_at' => '2000-01-01']))
            ->assertCreated();
        $this->assertNotSame(999, $response->json('data.id'));
        $this->assertDatabaseMissing('products', ['id' => 999]);
    }

    public function test_it_reads_one_product(): void
    {
        $product = Product::factory()->create($this->payload());
        $this->getJson('/api/products/'.$product->id)->assertOk()->assertJsonPath('data.name', 'Cimento CP II');
    }

    public function test_it_replaces_a_product_with_put(): void
    {
        $product = Product::factory()->create();
        $this->putJson('/api/products/'.$product->id, $this->payload(['name' => 'Cimento atualizado', 'stock' => 5]))
            ->assertOk()->assertJsonPath('data.name', 'Cimento atualizado')->assertJsonPath('data.stock', 5);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'name' => 'Cimento atualizado', 'stock' => 5]);
    }

    public function test_patch_updates_only_submitted_fields(): void
    {
        $product = Product::factory()->create($this->payload());
        $this->patchJson('/api/products/'.$product->id, ['stock' => 0])->assertOk()
            ->assertJsonPath('data.stock', 0)->assertJsonPath('data.price', '34.90')->assertJsonPath('data.name', $product->name);
    }

    public function test_put_requires_all_fields_and_leaves_original_data_intact(): void
    {
        $product = Product::factory()->create($this->payload());
        $this->putJson('/api/products/'.$product->id, ['name' => 'Novo nome'])
            ->assertUnprocessable()->assertJsonValidationErrors(['description', 'brand', 'price', 'stock']);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'name' => 'Cimento CP II']);
    }

    public function test_it_deletes_a_product_and_returns_no_content(): void
    {
        $product = Product::factory()->create();
        $this->deleteJson('/api/products/'.$product->id)->assertNoContent();
        $this->assertDatabaseMissing('products', ['id' => $product->id]);
        $this->getJson('/api/products/'.$product->id)->assertNotFound();
    }

    public function test_missing_products_return_json_for_all_resource_actions(): void
    {
        $this->get('/api/products/999')->assertNotFound()->assertJsonPath('message', 'Recurso não encontrado.');
        $this->putJson('/api/products/999', $this->payload())->assertNotFound();
        $this->deleteJson('/api/products/999')->assertNotFound();
        $this->getJson('/api/products/invalid')->assertNotFound();
    }

    #[DataProvider('invalidProducts')]
    public function test_it_rejects_invalid_fields_without_saving(string $field, mixed $value): void
    {
        $this->postJson('/api/products', $this->payload([$field => $value]))
            ->assertUnprocessable()->assertJsonValidationErrors($field);
        $this->assertDatabaseCount('products', 0);
    }

    public static function invalidProducts(): array
    {
        return [
            'empty name' => ['name', '  '],
            'long name' => ['name', str_repeat('a', 151)],
            'empty brand' => ['brand', null],
            'long brand' => ['brand', str_repeat('a', 101)],
            'empty description' => ['description', ''],
            'long description' => ['description', str_repeat('a', 2001)],
            'negative price' => ['price', '-1.00'],
            'too many decimals' => ['price', '1.001'],
            'comma in API price' => ['price', '1,20'],
            'excessive price' => ['price', '100000000.00'],
            'non numeric price' => ['price', 'abc'],
            'null price' => ['price', null],
            'negative stock' => ['stock', -1],
            'fractional stock' => ['stock', 1.5],
            'excessive stock' => ['stock', 2147483648],
            'null stock' => ['stock', null],
        ];
    }

    public function test_it_rejects_missing_required_fields(): void
    {
        $this->postJson('/api/products', [])->assertUnprocessable()
            ->assertJsonValidationErrors(['name', 'description', 'brand', 'price', 'stock']);
    }

    public function test_search_and_stock_filters_are_combined_correctly(): void
    {
        Product::factory()->create(['name' => 'Cimento', 'brand' => 'Marca A', 'stock' => 4]);
        Product::factory()->create(['name' => 'Tinta', 'brand' => 'Cimento', 'stock' => 0]);
        Product::factory()->create(['name' => 'Parafuso', 'brand' => 'Marca B', 'stock' => 4]);

        $this->getJson('/api/products?search=Cimento&stock=low')->assertOk()
            ->assertJsonCount(1, 'data')->assertJsonPath('data.0.name', 'Cimento')
            ->assertJsonPath('stats.total_products', 3);
    }

    public function test_search_for_zero_is_not_ignored(): void
    {
        Product::factory()->create(['name' => 'Produto 0', 'brand' => 'ABC']);
        Product::factory()->create(['name' => 'Produto A', 'brand' => 'ABC']);
        $this->getJson('/api/products?search=0')->assertOk()->assertJsonCount(1, 'data');
    }

    public function test_search_does_not_interpolate_sql(): void
    {
        Product::factory()->create();
        $this->getJson('/api/products?'.http_build_query(['search' => "' OR 1=1 --"]))
            ->assertOk()->assertJsonCount(0, 'data');
    }

    public function test_pagination_and_sorting_work(): void
    {
        Product::factory()->create(['name' => 'C', 'price' => '30.00']);
        Product::factory()->create(['name' => 'A', 'price' => '10.00']);
        Product::factory()->create(['name' => 'B', 'price' => '20.00']);

        $this->getJson('/api/products?per_page=2&page=2&sort=price_asc')->assertOk()
            ->assertJsonCount(1, 'data')->assertJsonPath('data.0.name', 'C')
            ->assertJsonPath('meta.total', 3)->assertJsonPath('meta.last_page', 2);
        $this->getJson('/api/products?sort=name')->assertOk()->assertJsonPath('data.0.name', 'A');
        $this->getJson('/api/products?sort=price_desc')->assertOk()->assertJsonPath('data.0.name', 'C');
    }

    public function test_it_validates_query_parameters(): void
    {
        $this->getJson('/api/products?per_page=1000&page=0&stock=invalid&sort=invalid')
            ->assertUnprocessable()->assertJsonValidationErrors(['per_page', 'page', 'stock', 'sort']);
    }

    public function test_stock_boundaries_and_global_totals_are_correct(): void
    {
        Product::factory()->create(['price' => '10.50', 'stock' => 0]);
        Product::factory()->create(['price' => '10.50', 'stock' => 1]);
        Product::factory()->create(['price' => '10.50', 'stock' => 5]);
        Product::factory()->create(['price' => '10.50', 'stock' => 6]);

        $response = $this->getJson('/api/products?stock=empty');
        $response->assertOk()->assertJsonCount(1, 'data')->assertJsonPath('stats.total_products', 4)
            ->assertJsonPath('stats.total_units', 12)->assertJsonPath('stats.low_stock', 2)
            ->assertJsonPath('stats.out_of_stock', 1);
        $this->assertSame(126.0, (float) $response->json('stats.total_value'));
        $this->getJson('/api/products?stock=low')->assertJsonCount(2, 'data');
        $this->getJson('/api/products?stock=available')->assertJsonCount(3, 'data');
    }

    public function test_cors_preflight_allows_the_frontend_origin(): void
    {
        $this->options('/api/products', [], [
            'Origin' => 'http://127.0.0.1:5173',
            'Access-Control-Request-Method' => 'POST',
            'Access-Control-Request-Headers' => 'Content-Type',
        ])->assertNoContent()->assertHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:5173');
    }

    public function test_cors_does_not_allow_an_unlisted_origin(): void
    {
        $this->options('/api/products', [], [
            'Origin' => 'https://unlisted.example',
            'Access-Control-Request-Method' => 'POST',
        ])->assertHeaderMissing('Access-Control-Allow-Origin');
    }

    public function test_demo_seeder_is_idempotent_and_preserves_changes(): void
    {
        $this->seed(ProductSeeder::class);
        $product = Product::first();
        $product->update(['stock' => 99]);
        $this->seed(ProductSeeder::class);
        $this->assertDatabaseCount('products', 14);
        $this->assertSame(99, $product->refresh()->stock);
    }
}
