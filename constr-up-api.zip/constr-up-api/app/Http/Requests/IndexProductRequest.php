<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class IndexProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'search' => ['nullable', 'string', 'max:120'],
            'page' => ['sometimes', 'integer', 'min:1'],
            'per_page' => ['sometimes', 'integer', 'between:1,100'],
            'stock' => ['sometimes', Rule::in(['all', 'available', 'low', 'empty'])],
            'sort' => ['sometimes', Rule::in(['newest', 'name', 'price_asc', 'price_desc', 'stock'])],
        ];
    }

    public function attributes(): array
    {
        return ['search' => 'busca', 'page' => 'página', 'per_page' => 'itens por página', 'stock' => 'filtro de estoque', 'sort' => 'ordenação'];
    }
}
