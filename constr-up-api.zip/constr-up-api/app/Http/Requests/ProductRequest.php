<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $presence = $this->isMethod('PATCH') ? ['sometimes', 'required'] : ['required'];

        return [
            'name' => [...$presence, 'string', 'max:150'],
            'description' => [...$presence, 'string', 'max:2000'],
            'brand' => [...$presence, 'string', 'max:100'],
            'price' => [...$presence, 'numeric', 'min:0', 'max:99999999.99', 'regex:/^\d{1,8}(?:\.\d{1,2})?$/'],
            'stock' => [...$presence, 'integer', 'min:0', 'max:2147483647'],
        ];
    }

    public function attributes(): array
    {
        return ['name' => 'nome', 'description' => 'descrição', 'brand' => 'marca', 'price' => 'preço', 'stock' => 'estoque'];
    }

    public function messages(): array
    {
        return ['price.regex' => 'Informe o preço com ponto decimal e até duas casas decimais.'];
    }
}
