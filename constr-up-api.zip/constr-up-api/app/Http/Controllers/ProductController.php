<?php

namespace App\Http\Controllers;

use App\Http\Requests\IndexProductRequest;
use App\Http\Requests\ProductRequest;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class ProductController extends Controller
{
    public function index(IndexProductRequest $request): AnonymousResourceCollection
    {
        $filters = $request->validated();
        $query = Product::query();

        $search = $filters['search'] ?? '';
        if ($search !== '') {
            $query->where(function (Builder $query) use ($search): void {
                $query->whereLike('name', '%'.$search.'%')->orWhereLike('brand', '%'.$search.'%');
            });
        }

        match ($filters['stock'] ?? 'all') {
            'available' => $query->where('stock', '>', 0),
            'low' => $query->whereBetween('stock', [1, 5]),
            'empty' => $query->where('stock', 0),
            default => null,
        };

        match ($filters['sort'] ?? 'newest') {
            'name' => $query->orderBy('name')->orderBy('id'),
            'price_asc' => $query->orderBy('price')->orderBy('id'),
            'price_desc' => $query->orderByDesc('price')->orderBy('id'),
            'stock' => $query->orderBy('stock')->orderBy('id'),
            default => $query->orderByDesc('id'),
        };

        // O resumo usa todo o catálogo; os filtros afetam apenas a lista paginada.
        $stats = Product::query()->selectRaw(
            'COUNT(*) AS total_products, COALESCE(SUM(stock), 0) AS total_units,
             COALESCE(SUM(price * stock), 0) AS total_value,
             COALESCE(SUM(CASE WHEN stock BETWEEN 1 AND 5 THEN 1 ELSE 0 END), 0) AS low_stock,
             COALESCE(SUM(CASE WHEN stock = 0 THEN 1 ELSE 0 END), 0) AS out_of_stock'
        )->first();

        return ProductResource::collection($query->paginate((int) ($filters['per_page'] ?? 12))->withQueryString())
            ->additional(['stats' => [
                'total_products' => (int) $stats->total_products,
                'total_units' => (int) $stats->total_units,
                'total_value' => (string) $stats->total_value,
                'low_stock' => (int) $stats->low_stock,
                'out_of_stock' => (int) $stats->out_of_stock,
            ]]);
    }

    public function store(ProductRequest $request): JsonResponse
    {
        $product = Product::create($request->validated());

        return (new ProductResource($product))->response()->setStatusCode(201);
    }

    public function show(Product $product): ProductResource
    {
        return new ProductResource($product);
    }

    public function update(ProductRequest $request, Product $product): ProductResource
    {
        $product->update($request->validated());

        return new ProductResource($product->refresh());
    }

    public function destroy(Product $product): Response
    {
        $product->delete();

        return response()->noContent();
    }
}
