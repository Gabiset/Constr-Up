<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        // Dados demonstrativos. Reexecutar não duplica nem altera produtos já existentes.
        $products = [
            ['Cimento CP II 50 kg', 'Cimento de uso geral para alvenaria e concreto.', 'Votoran', '34.90', 120],
            ['Argamassa AC III 20 kg', 'Argamassa para assentamento de porcelanatos.', 'Quartzolit', '39.90', 48],
            ['Tinta acrílica branca 18 L', 'Acabamento fosco para ambientes internos.', 'Coral', '289.90', 3],
            ['Tijolo cerâmico 8 furos', 'Bloco cerâmico para alvenaria de vedação.', 'Cerâmica União', '1.89', 950],
            ['Tubo PVC soldável 25 mm', 'Tubo de 6 metros para instalações de água fria.', 'Tigre', '24.50', 72],
            ['Furadeira de impacto 650 W', 'Mandril de 13 mm e velocidade variável.', 'Bosch', '349.90', 0],
            ['Rejunte flexível cinza 1 kg', 'Rejunte para revestimentos cerâmicos.', 'Quartzolit', '8.90', 36],
            ['Luva de proteção tamanho G', 'Luva para manuseio de materiais e ferramentas.', 'Vonder', '12.90', 5],
            ['Trena profissional 5 m', 'Fita metálica com trava e corpo emborrachado.', 'Stanley', '39.90', 22],
            ['Massa corrida PVA 25 kg', 'Para nivelar superfícies em áreas internas.', 'Suvinil', '89.90', 18],
            ['Disco de corte 115 mm', 'Disco abrasivo para corte de metais.', 'Bosch', '6.50', 64],
            ['Parafuso 4,5 × 50 mm', 'Caixa com 100 parafusos para madeira.', 'Vonder', '18.90', 0],
            ['Impermeabilizante 3,6 L', 'Proteção contra umidade em superfícies cimentícias.', 'Vedacit', '74.90', 4],
            ['Torneira de parede cromada', 'Bica móvel para instalação em cozinha.', 'Docol', '159.90', 12],
        ];

        foreach ($products as [$name, $description, $brand, $price, $stock]) {
            Product::firstOrCreate(['name' => $name, 'brand' => $brand], compact('description', 'price', 'stock'));
        }
    }
}
