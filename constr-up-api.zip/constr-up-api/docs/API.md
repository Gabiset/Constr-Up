# API de produtos

Base local: http://127.0.0.1:8000/api

Envie **Accept: application/json** em todas as requisições e **Content-Type: application/json** ao enviar um corpo. Os endpoints deste teste não exigem autenticação.

## Rotas

| Método | Caminho | Resultado |
| --- | --- | --- |
| GET | /products | Lista paginada de produtos |
| POST | /products | Criação, HTTP 201 |
| GET | /products/{id} | Consulta individual |
| PUT | /products/{id} | Edição completa dos cinco campos |
| PATCH | /products/{id} | Edição apenas dos campos enviados |
| DELETE | /products/{id} | Exclusão, HTTP 204 sem corpo |

## Campos

| Campo JSON | Significado | Regras |
| --- | --- | --- |
| name | Nome | Texto obrigatório, até 150 caracteres |
| description | Descrição | Texto obrigatório, até 2.000 caracteres |
| brand | Marca | Texto obrigatório, até 100 caracteres |
| price | Preço | De 0 a 99.999.999,99; no JSON, ponto decimal e até duas casas |
| stock | Estoque | Inteiro de 0 a 2.147.483.647 |

O preço é armazenado como **DECIMAL(10,2)** e retornado como string com duas casas decimais. O front-end aceita vírgula e normaliza o valor antes de enviá-lo. O estoque conta unidades inteiras. Nomes iguais são permitidos, pois o enunciado não define um SKU ou uma regra de unicidade.

## Criar um produto

Exemplo para Bash, Git Bash ou terminal compatível:

~~~bash
curl -X POST http://127.0.0.1:8000/api/products \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{"name":"Cimento CP II","description":"Saco de 50 kg","brand":"Votoran","price":"34.90","stock":10}'
~~~

Resposta HTTP 201:

~~~json
{
  "data": {
    "id": 1,
    "name": "Cimento CP II",
    "description": "Saco de 50 kg",
    "brand": "Votoran",
    "price": "34.90",
    "stock": 10,
    "created_at": "2026-10-28T12:00:00.000000Z",
    "updated_at": "2026-10-28T12:00:00.000000Z"
  }
}
~~~

O ID e as datas acima são ilustrativos.

## Consultar, editar e excluir

Substitua 1 pelo ID devolvido pela criação.

~~~bash
curl http://127.0.0.1:8000/api/products/1 -H 'Accept: application/json'

curl -X PATCH http://127.0.0.1:8000/api/products/1 \
  -H 'Accept: application/json' -H 'Content-Type: application/json' \
  -d '{"stock":5}'

curl -X DELETE http://127.0.0.1:8000/api/products/1 \
  -H 'Accept: application/json'
~~~

Também é possível abrir **docs/requests.http** com uma extensão de cliente HTTP no editor.

## Paginação, busca e filtros

~~~text
GET /products?search=cimento&stock=low&sort=price_asc&page=1&per_page=12
~~~

| Parâmetro | Valores | Padrão |
| --- | --- | --- |
| search | Texto de até 120 caracteres; nome ou marca | Sem busca |
| page | Inteiro a partir de 1 | 1 |
| per_page | Inteiro entre 1 e 100 | 12 |
| stock | all, available, low, empty | all |
| sort | newest, name, price_asc, price_desc, stock | newest |

**available** inclui qualquer produto com estoque maior que zero; **low** inclui de 1 a 5 unidades; **empty** inclui estoque zero. Busca e filtro de estoque são combinados. A busca usa LIKE do banco: % e _ funcionam como curingas.

A resposta inclui:

- **data:** produtos da página.
- **links** e **meta:** URLs e metadados de paginação do Laravel.
- **stats:** resumo de todo o catálogo, independentemente dos filtros.

O resumo contém **total_products**, **total_units**, **total_value**, **low_stock** e **out_of_stock**. O card de atenção da interface soma os dois últimos.

## Erros

Dados inválidos retornam HTTP 422 e mensagens de campo:

~~~json
{
  "message": "Revise os dados informados.",
  "errors": {
    "stock": ["O campo estoque deve ser no mínimo 0."]
  }
}
~~~

Produto ou rota inexistente retorna HTTP 404:

~~~json
{ "message": "Recurso não encontrado." }
~~~

As consultas usam os parâmetros vinculados do Eloquent. Os campos de ordenação vêm de uma lista permitida. Apenas os cinco campos previstos podem ser gravados.
